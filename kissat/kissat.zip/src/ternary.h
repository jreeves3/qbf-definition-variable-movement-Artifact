#ifndef _ternary_h_INCLUDED
#define _ternary_h_INCLUDED

struct kissat;

void kissat_ternary (struct kissat *);

#endif
