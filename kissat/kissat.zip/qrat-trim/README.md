# qrat-trim
Checking tool for QBF results in the QRAT format
