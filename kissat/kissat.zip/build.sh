#!/bin/sh

./configure && make

(cd qrat-trim; make)

